package com.wellsfargo.fsd.si.service;

import com.wellsfargo.fsd.si.model.SiModel;

public class SiService {
	
	
	
	public double getSimpleInterest(SiModel sim)
	{
		double result=sim.getPrincipal()*sim.getRate()*sim.getTime()/1200;
		return result;
	}
	
	public double getEMI(SiModel sim)
	{
		double p=sim.getPrincipal();
		double r=sim.getRate()/1200;
		double n=sim.getTime();
		System.out.println(p+" "+r+" "+n);
		double result=p*r* ((Math.pow((1+r), n))/(Math.pow((1+r), n)-1));
		return result;
	}

}
