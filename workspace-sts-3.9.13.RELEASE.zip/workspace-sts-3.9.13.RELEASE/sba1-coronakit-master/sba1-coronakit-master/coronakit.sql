DROP DATABASE coronakitdb;

CREATE DATABASE coronakitdb;

USE coronakitdb;



CREATE TABLE item(
				pid integer primary key,
				pname varchar(20) not null,
				pcost varchar(20) not null,
				pdesc varchar(50) not null
				);
								
insert into item values(1,"Face Mask","99","N-95 Face Mask");
insert into item values(4,"Sanitizer","49","Dettol Sanitizer");
insert into item values(2,"Vitamin C","144","Boost immunity");
insert into item values(3,"Amla Juice","110","Patanjali Amla Juice");								
