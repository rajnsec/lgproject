package com.iiht.evaluation.coronokit.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.iiht.evaluation.coronokit.model.ProductMaster;




public class ProductMasterDao {
	
	public static final String INS_ITEM_QRY = "INSERT INTO item(pid,pname,pcost,pdesc) VALUES(?,?,?,?)";
	public static final String UPD_ITEM_QRY = "UPDATE item set pname=?,pcost=?,pdesc=? WHERE pid=?";
	public static final String DEL_ITEM_QRY = "DELETE FROM item WHERE pid=?";
	public static final String GET_ALL_ITEM_QRY = "SELECT pid,pname,pcost,pdesc FROM item";
	public static final String GET_ITEM_BY_ID_QRY = "SELECT pid,pname,pcost,pdesc FROM item WHERE pid=?";

	private String jdbcURL;
	private String jdbcUsername;
	private String jdbcPassword;
	private Connection jdbcConnection;

	public ProductMasterDao(String jdbcURL, String jdbcUsername, String jdbcPassword) {
        this.jdbcURL = jdbcURL;
        this.jdbcUsername = jdbcUsername;
        this.jdbcPassword = jdbcPassword;
    }

	protected void connect() throws SQLException {
		if (jdbcConnection == null || jdbcConnection.isClosed()) {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				throw new SQLException(e);
			}
			jdbcConnection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		}
	}

	protected void disconnect() throws SQLException {
		if (jdbcConnection != null && !jdbcConnection.isClosed()) {
			jdbcConnection.close();
		}
	}
	
	
	public List<ProductMaster> getAll(ProductMasterDao productMasterDao)   {
		List<ProductMaster> products = new ArrayList<>();
		
		try {
		
			productMasterDao.connect();
			PreparedStatement pst = jdbcConnection.prepareStatement(GET_ALL_ITEM_QRY);
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				ProductMaster product = new ProductMaster();
				product.setId(rs.getInt(1));
				product.setProductName(rs.getString(2));
				product.setCost(rs.getString(3));
				product.setProductDescription(rs.getString(4));
				
				products.add(product);
			}
			
			if(products.isEmpty()) {
				products=null;
			}
			productMasterDao.disconnect();

		
		}catch(SQLException e) {e.printStackTrace();}
			
		return products;
	} 
	public boolean deleteProduct(int productId, ProductMasterDao productMasterDao) {
		boolean isDeleted = false;
		try 
		{
			productMasterDao.connect();
			PreparedStatement pst = jdbcConnection.prepareStatement(DEL_ITEM_QRY);
			

			pst.setInt(1, productId);

			int rowsCount = pst.executeUpdate();

			isDeleted = rowsCount > 0;
			productMasterDao.disconnect();
		} catch (SQLException exp) {
			exp.printStackTrace();
		}
		return isDeleted;
	}
	
	public ProductMaster getById(int productId, ProductMasterDao productMasterDao) {
		ProductMaster product = null;

		try 
		{
			productMasterDao.connect();
			PreparedStatement pst = jdbcConnection.prepareStatement(GET_ITEM_BY_ID_QRY);

			pst.setInt(1, productId);
			
			ResultSet rs = pst.executeQuery();
			
			if(rs.next()) {
				product = new ProductMaster();
				product.setId(rs.getInt(1));
				product.setProductName(rs.getString(2));
				product.setCost(rs.getString(3));
				product.setProductDescription(rs.getString(4));
				productMasterDao.disconnect();
			}

		} catch (SQLException exp) {
			exp.printStackTrace();
		}

		return product;
	}
	
	public ProductMaster saveProduct(ProductMaster product, ProductMasterDao productMasterDao) {
		if (product != null) {
			try  {
				productMasterDao.connect();
				PreparedStatement pst = jdbcConnection.prepareStatement(UPD_ITEM_QRY);
				pst.setString(1, product.getProductName());
				pst.setString(2, product.getCost());
				pst.setString(3, product.getProductDescription());
				pst.setInt(4, product.getId());

				pst.executeUpdate();
				
				productMasterDao.disconnect();
			} catch (SQLException exp) {
				exp.printStackTrace();
			}
		}
	return  product;
	}
	// add DAO methods as per requirements
}