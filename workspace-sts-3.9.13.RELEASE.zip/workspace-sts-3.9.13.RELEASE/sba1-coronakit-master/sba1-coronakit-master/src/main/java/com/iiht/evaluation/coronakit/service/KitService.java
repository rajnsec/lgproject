package com.iiht.evaluation.coronakit.service;

public interface KitService {

}
