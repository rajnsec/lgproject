package com.iiht.evaluation.coronakit.service;

import java.sql.SQLException;
import java.util.List;

import com.iiht.evaluation.coronokit.dao.ProductMasterDao;
import com.iiht.evaluation.coronokit.model.ProductMaster;

public class ProductMasterServiceImpl implements ProductMasterService {
	ProductMasterDao productMasterDao=null;
	
	public ProductMasterServiceImpl(ProductMasterDao productMasterDao)
	{
		this.productMasterDao=productMasterDao;
	}
 
	@Override
	public List<ProductMaster> getAll() {
		// TODO Auto-generated method stub	
				
			return productMasterDao.getAll(productMasterDao);
		
		}

	@Override
	public boolean deleteProduct(int productid) {
		// TODO Auto-generated method stub
		return productMasterDao.deleteProduct(productid,productMasterDao);
	}

	@Override
	public ProductMaster getProductById(int productid) {
		// TODO Auto-generated method stub
		return productMasterDao.getById(productid, productMasterDao);
	}

	@Override
	public ProductMaster updateProduct(ProductMaster product) {
		// TODO Auto-generated method stub
		return productMasterDao.saveProduct(product, productMasterDao);
	}
	}


