package com.iiht.evaluation.coronakit.service;

import java.util.List;

import com.iiht.evaluation.coronokit.model.ProductMaster;



public interface ProductMasterService {
	
	List<ProductMaster> getAll();

	boolean deleteProduct(int productid);
	
	ProductMaster getProductById(int productid);
	ProductMaster updateProduct(ProductMaster product);
}
