package com.wellsfargo.fsd.cms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wellsfargo.fsd.cms.entity.Contacts;
import com.wellsfargo.fsd.cms.exception.ContactException;

public class ContactDaoJdbcImpl implements ContactDao {
	
	public static final String INS_CONT_QRY=" INSERT into Contacts values(?,?,?,?)";
	public static final String DEL_CONT_QRY="DELETE from Contacts where cId=?";
	public static final String GETBYID_CONT_QRY="SELECT Cid,Cname,dob,mobile from Contacts where cId=?";
	public static final String GETALL_CONT_QRY="SELECT * from Contacts";
	

	public Contacts addContact(Contacts contact) throws ContactException {
		if(contact!=null)
		{
			try(Connection con=ConnectionFactory.getConnection();
					PreparedStatement pst=con.prepareStatement(INS_CONT_QRY);)
			{
				pst.setInt(1, contact.getContactId());
				pst.setString(2, contact.getFullName());
				pst.setDate(3, Date.valueOf(contact.getDateOfBirth()));
				pst.setString(4,contact.getMobile());
				
				pst.executeUpdate();
				
			}catch(SQLException exp) {throw new ContactException("Adding conatct failed");}
		}
		return contact;
	}

	public boolean deleteContact(int contactId) throws ContactException {
		boolean isDeleted=false;
		try(Connection con=ConnectionFactory.getConnection();
				PreparedStatement pst=con.prepareStatement(DEL_CONT_QRY);)
		{
			pst.setInt(1, contactId);
			
			int rowCount=pst.executeUpdate();
			isDeleted=rowCount>0;

			
		}catch(SQLException exp) {throw new ContactException("Deleting conatct failed");}
	
	return isDeleted;
	}

	public Contacts getById(int contactId) throws ContactException {
		
		Contacts contact=null;
		try(Connection con=ConnectionFactory.getConnection();
				PreparedStatement pst=con.prepareStatement(GETBYID_CONT_QRY);)
		{
			pst.setInt(1, contactId);
			
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				contact=new Contacts();
				contact.setContactId(rs.getInt(1));
				contact.setFullName(rs.getString(2));
				contact.setDateOfBirth(rs.getDate(3).toLocalDate());
				contact.setMobile(rs.getString(4));
			}

			
		}catch(SQLException exp) {throw new ContactException("Fetching By ID failed");}
		return contact;
	}

	public List<Contacts> getAllContacts() throws ContactException {
		// TODO Auto-generated method stub
List<Contacts> contacts = new ArrayList<>();
		
		try (Connection con = ConnectionFactory.getConnection();
				PreparedStatement pst = con.prepareStatement(GETALL_CONT_QRY);) {
			
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				Contacts contact = new Contacts();
				contact.setContactId(rs.getInt(1));
				contact.setFullName(rs.getString(2));
				contact.setDateOfBirth(rs.getDate(3).toLocalDate());
				contact.setMobile(rs.getString(4));
				
				contacts.add(contact);
			}
			
			if(contacts.isEmpty()) {
				contacts=null;
			}

		} catch (SQLException exp) {
			throw new ContactException("Feteching Contact failed!");
		}
		
		return contacts;
	}
	
	

}
