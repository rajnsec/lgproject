package com.wellsfargo.fsd.cms.service;

import java.util.List;

import com.wellsfargo.fsd.cms.entity.Contacts;
import com.wellsfargo.fsd.cms.exception.ContactException;

public interface ContactService {
	
	Contacts validateAndAdd(Contacts contact) throws ContactException;
	
	
	boolean deleteContact(int contactId) throws ContactException;
	
	Contacts getContact(int contactId) throws ContactException;
	List<Contacts> getAllContacts() throws ContactException;

}
