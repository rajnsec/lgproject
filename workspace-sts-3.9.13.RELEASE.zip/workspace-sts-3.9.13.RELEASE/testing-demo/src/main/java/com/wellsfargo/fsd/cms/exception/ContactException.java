package com.wellsfargo.fsd.cms.exception;

public class ContactException extends Exception {
	
	public ContactException(String ErrMsg)
	{
		super(ErrMsg);
	}

}
