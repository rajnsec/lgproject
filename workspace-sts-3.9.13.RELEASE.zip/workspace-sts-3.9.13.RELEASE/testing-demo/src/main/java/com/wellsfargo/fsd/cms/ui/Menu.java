package com.wellsfargo.fsd.cms.ui;

public enum Menu {
	ADD,DELETE,FIND,LIST,QUIT;

}
