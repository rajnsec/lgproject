package com.wellsfargo.fsd.cms.dao;

import java.util.List;

import com.wellsfargo.fsd.cms.entity.Contacts;
import com.wellsfargo.fsd.cms.exception.ContactException;

public interface ContactDao {
	
	 Contacts addContact(Contacts contact) throws ContactException;
	 boolean deleteContact(int contactId)throws ContactException;
	 Contacts getById(int contactId)throws ContactException;
	 List<Contacts> getAllContacts()throws ContactException;

}
