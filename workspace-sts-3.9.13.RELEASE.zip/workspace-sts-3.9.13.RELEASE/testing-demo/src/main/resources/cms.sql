DROP DATABASE cmsDb;

CREATE DATABASE cmsDB;

USE cmsDB;

CREATE TABLE Contacts (
	cid int primary key,
	cname varchar(20) not null,
	dob date not null,
	mobile char(10) unique
);

INSERT INTO Contacts values
(1, "RAJ", "1988-05-12", "8787878787"),
(3, "Abhishek", "1983-05-12", "9999878787"),
(2, "Ramling", "1981-05-12", "8781234287"),
(4, "Raghav", "1987-05-12", "8444478787");