package com.wellsfargo.sms.exception;

public class StudentException extends Exception {
	
	public StudentException(String errMsg)
	{
		super(errMsg);
	}

}
