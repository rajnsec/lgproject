package com.wellsfargo.fsd.sms.service;

import com.wellsfargo.fsd.sms.model.StudentModel;
import com.wellsfargo.sms.exception.StudentException;

public interface StudentService {
	
	StudentModel validateAndAdd(StudentModel sm) throws StudentException;
	boolean deleteStudent(int sid) throws StudentException;
	StudentModel findStudent(int sid) throws StudentException;

}
