package com.wellsfargo.fsd.sms.model;

public class StudentModel {
	

	private int studentId;
	private String studentName;
	private String phone;
	private String city;
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	@Override
	public String toString() {
		return " [studentId=" + studentId + ", studentName=" + studentName + ", phone=" + phone + ", city="
				+ city + "]";
	}

}
