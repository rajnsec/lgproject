package com.wellsfargo.fsd.sms.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wellsfargo.fsd.sms.model.StudentModel;
import com.wellsfargo.fsd.sms.service.StudentServiceImpl;
import com.wellsfargo.sms.exception.StudentException;

/**
 * Servlet implementation class addServlet
 */
@WebServlet("/delete")
public class deleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		StudentModel sm=new StudentModel();
		StudentServiceImpl ssi=new StudentServiceImpl();
		try {
			ssi.deleteStudent(Integer.parseInt(request.getParameter("sid")));
			String msg="Student deleted successfully.";
			System.out.println(msg);
			request.setAttribute("msg", msg);
			} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		RequestDispatcher rd=request.getRequestDispatcher("deleteStudent.jsp");
		rd.forward(request, response);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
