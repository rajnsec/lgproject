package com.wellsfargo.fsd.sms.dao;

import com.wellsfargo.fsd.sms.model.StudentModel;
import com.wellsfargo.sms.exception.StudentException;

public interface StudentDao {
	
	StudentModel addStudent(StudentModel sm) throws StudentException;
	boolean deleteStudent(int sid) throws StudentException;
	StudentModel findStudent(int sid) throws StudentException;

}
