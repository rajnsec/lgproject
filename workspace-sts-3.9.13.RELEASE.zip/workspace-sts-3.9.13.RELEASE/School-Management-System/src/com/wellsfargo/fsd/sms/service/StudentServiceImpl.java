package com.wellsfargo.fsd.sms.service;

import com.wellsfargo.fsd.sms.dao.StudentDao;
import com.wellsfargo.fsd.sms.dao.StudentDaoImpl;
import com.wellsfargo.fsd.sms.model.StudentModel;
import com.wellsfargo.sms.exception.StudentException;

public class StudentServiceImpl implements StudentService {
	
	StudentDao cd=null;
	
	public StudentServiceImpl()
	{
		cd= new StudentDaoImpl();
	}

	@Override
	public StudentModel validateAndAdd(StudentModel sm) throws StudentException {
		// TODO Auto-generated method stub
		
		
		return cd.addStudent(sm);
	}

	@Override
	public boolean deleteStudent(int sid) throws StudentException {
		// TODO Auto-generated method stub
		return cd.deleteStudent(sid);
	}

	@Override
	public StudentModel findStudent(int sid) throws StudentException {
		// TODO Auto-generated method stub
		return cd.findStudent(sid);
	}
	
	

}
