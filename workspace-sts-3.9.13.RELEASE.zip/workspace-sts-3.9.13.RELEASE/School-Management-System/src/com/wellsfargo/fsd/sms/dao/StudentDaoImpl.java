package com.wellsfargo.fsd.sms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.wellsfargo.fsd.sms.model.StudentModel;
import com.wellsfargo.sms.exception.StudentException;

public class StudentDaoImpl implements StudentDao {
	
	public static final String ADD_STUD_QRY="INSERT into student values(?,?,?,?)";
	public static final String DEL_STUD_QRY="DELETE from student where sid=?";
	public static final String FIND_STUD_QRY="SELECT * from student where sid=?";

	@Override
	public StudentModel addStudent(StudentModel sm) throws StudentException {
		// TODO Auto-generated method stub
		
		try(Connection con=ConnectionFactory.getConnection();
			PreparedStatement pst=con.prepareStatement(ADD_STUD_QRY);)
		{		
			
			pst.setInt(1, sm.getStudentId());
			pst.setString(2, sm.getStudentName());
			pst.setString(3, sm.getPhone());
			pst.setString(4, sm.getCity());
			
			
			pst.executeUpdate();
		}catch(SQLException exp) {throw new StudentException("Addition Failed");}
		
		return sm;
	}

	@Override
	public boolean deleteStudent(int sid) throws StudentException {
		// TODO Auto-generated method stub
		boolean isDeleted=false;
		try(Connection con=ConnectionFactory.getConnection();
				PreparedStatement pst=con.prepareStatement(DEL_STUD_QRY);)
		{
		pst.setInt(1, sid);
		int rowNum=pst.executeUpdate();
		isDeleted=rowNum>0;
		}catch(SQLException exp) {throw new StudentException("Delete Failed");}
		return isDeleted;
	}

	@Override
	public StudentModel findStudent(int sid) throws StudentException {
		// TODO Auto-generated method stub
		StudentModel sm=new StudentModel();
		try(Connection con=ConnectionFactory.getConnection();
				PreparedStatement pst=con.prepareStatement(FIND_STUD_QRY);)
		{
		pst.setInt(1, sid);
		ResultSet rs=pst.executeQuery();
		while (rs.next())
		{
			sm.setStudentId(rs.getInt(1));
			sm.setStudentName(rs.getString(2));
			sm.setPhone(rs.getString(3));
			sm.setCity(rs.getString(4));
		}
		}catch(SQLException exp) {throw new StudentException("Fetching failed");}
		return sm;
	}

}
