drop database smsDb;

create database smsDb;

use smsDb;

Create table student (
					sid int primary key,
					sname varchar(30) not null,
					phone char(10) unique,
					city varchar(20)
					);
					
insert into student values(1,"Raj","9739715817","Bhurkunda");
insert into student values(4,"Ajit","9229715817","Koderma");
insert into student values(2,"Anuj","9733315817","Hazaribagh");
insert into student values(3,"Basant","9739715444","Giddi");
